<?php 
    error_reporting(0);
    include 'koneksi.php';
    $kontak = mysqli_query($conn, "SELECT telp, email, address FROM admin WHERE admin_id = 1");
    $a = mysqli_fetch_object($kontak);
    $produk = mysqli_query($conn, "SELECT * FROM product WHERE product_id = '".$_GET['id']."' ");
    $p = mysqli_fetch_object($produk);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" >
    <meta name="viewport" content="width=device-width, initial-scale=1" >
    <title> Responsi PemWeb</title>
    <link rel="stylesheet"  href="style.css" >      
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Quicksand&display=swap" rel="stylesheet">
</head>
<body>
     <!-- header -->
    <header>
        <div class="container">   
            <h1><a href="index.php">Responsi Pemweb</a></h1>
            <ul>
                <li><a href="produk.php">Produk</a></li>
                
            </ul>
        </div>  
    </header>

    <!-- search-->
   <div class="search">
        <div class="container">
            <form action="produk.php">
                <input type="text" name="search" placeholder="K-Pop Album" value="<?php echo $_GET['search']?>">
                <input type="hidden" class=" kat" value=" <?php echo $_GET['kat']?> ">
                <input type="submit" name="cari" value="Search ">
            </form>
        </div>
   </div>

    <!-- produk detail-->
    <div class="section">
        <div class="container">
            <h3>Detail Produk</h3>
            <div class="box">
                <div class="col-2">
                    <img src="produk/<?php echo $p->product_image ?>" width="90%" >
                </div>
                <div class="col-2">
                    <h3> <?php echo $p->product_name ?> </h3>
                    <h4>Rp. <?php echo number_format($p->product_price)?></h4>
                    <p>Deskripsi: <br>
                        <?php echo $p->product_description ?>
                    </p>
                    <p><a href="https://api.whatsapp.com/send?phone=<?php echo $a->telp?>&text=Hai, saya tertarik dengan produk Anda."target="_blank">Hubungi via Whatsapp <img src="img/whatsapp.png" width="40px"></a></p>
                </div>
            </div>
        </div>
    </div>
        <!-- footer -->
        <div class="footer">
            <div class="container">
                <h4>Alamat</h4>
                <p> <?php echo $a->address?> </p>

                <h4>Email</h4>
                <p> <?php echo $a->email?> </p>

                <h4>No.Hp</h4>
                <p> <?php echo $a->telp?> </p>
                <small>Copyright &copy; 2020 - Responsi PemWeb. </small>

            </div>
        </div>
</body>
</html>
