<?php 
    $host = "localhost";
	$username = "root";
	$password = "";
	$database = "responsi_pemweb";
	
    $conn = mysqli_connect($host, $username, $password,$database) or die ('Gagal Terhubung ke Database');

	
?>