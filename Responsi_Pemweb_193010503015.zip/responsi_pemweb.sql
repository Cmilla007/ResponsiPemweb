-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 24, 2021 at 03:29 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `responsi_pemweb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(50) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `telp` varchar(100) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `address` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_name`, `username`, `password`, `telp`, `email`, `address`) VALUES
(1, 'Milla', 'admin', '1234567', '+62822534411', 'Milla7@gmail.com', 'Jl.Rajawali No.109, Palangka Raya, Kalimantan Tengah');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `category_name`) VALUES
(4, 'EXO'),
(5, 'AESPA'),
(6, 'BLACKPINK'),
(7, 'BTS'),
(8, 'SUPER JUNIOR'),
(9, 'TWICE'),
(10, 'IU'),
(11, 'ASTRO'),
(12, 'Stray Kids'),
(13, '2PM');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `product_id` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `product_name` varchar(100) DEFAULT NULL,
  `product_price` int(11) DEFAULT NULL,
  `product_description` text DEFAULT NULL,
  `product_image` varchar(100) DEFAULT NULL,
  `product_status` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `category_id`, `product_name`, `product_price`, `product_description`, `product_image`, `product_status`) VALUES
(9, 6, 'Kill This Love  ', 430000, '<p>Package</p>\r\n\r\n<p>- 2 Out Box(160 x 211 x 20mm / Black + Pink Ver)</p>\r\n\r\n<p>- 2 CD(Black + Pink Ver)</p>\r\n\r\n<p>- 2 Photobook(52p / Black + Pink Ver)</p>\r\n\r\n<p>- 2 Photo Zine(16p / Black + Pink Ver)</p>\r\n\r\n<p>- 2 Accordion Lyrics Book(10P / Black + Pink Ver)</p>\r\n\r\n<p>- 2 Photocard(Random 4 out of 16)</p>\r\n\r\n<p>- 2 Polaroid Photocard(Random 1 out of 8)</p>\r\n\r\n<p>- 2 Sticker SET(6Sheets / Black + Pink Ver)</p>\r\n\r\n<p>- 2 Folded Poster(Random 1 out of 4)</p>\r\n\r\n<p>- 2 Poster(1st Press Only / Black + Pink Ver)</p>\r\n', 'produk1621660915.jpg ', 1),
(10, 6, 'BLACKPINK - How You Like That   ', 470000, '<p>BLACKPINK SPECIAL EDITION - How You Like That CD + Poster</p>\r\n\r\n<p>Package</p>\r\n\r\n<p>- Cover : 220 x 300 x 15mm</p>\r\n\r\n<p>- CD</p>\r\n\r\n<p>- Photobook : 132p</p>\r\n\r\n<p>- Polaroid : Random 1 out of 16</p>\r\n\r\n<p>- Postcard : Random 1 out of 8</p>\r\n\r\n<p>- Folded Poster</p>\r\n\r\n<p>- Poster : 1st Press Only</p>\r\n', 'produk1621686591.jpg ', 1),
(11, 6, 'BLACKPINK Jennie - Solo ', 375500, '<p>JENNIE Single Album - SOLO</p>\r\n\r\n<p>Package</p>\r\n\r\n<p>- CD</p>\r\n\r\n<p>- Photobook(72p)</p>\r\n\r\n<p>- Lyrics Postcard(Random 1 Out of 2)</p>\r\n\r\n<p>- Photocard(Random 1 Out of 5)</p>\r\n\r\n<p>- Poster(1st Press Only)</p>\r\n', 'produk1621662087.jpg ', 1),
(12, 6, 'Square Up - BLACKPINK 1st Mini Album  ', 373200, '<p>BLACKPINK 1st Mini Album - Square Up (Black ver) CD + Poster</p>\r\n\r\n<p>Package</p>\r\n\r\n<p>- CD</p>\r\n\r\n<p>- Photobook</p>\r\n\r\n<p>- Lenticular Lyrics Book</p>\r\n\r\n<p>- Postcard</p>\r\n\r\n<p>- Random Photocard</p>\r\n\r\n<p>- Randon Selfie Photocard</p>\r\n\r\n<p>- Poster(1st Press Only)</p>\r\n', 'produk1621662482.jpg   ', 1),
(15, 6, 'ROSÉ (BLACKPINK) - First Single Album', 373400, '<h1>ROS&Eacute; (BLACKPINK) - First Single Album -R-</h1>\r\n\r\n<p>Package Box</p>\r\n\r\n<p>- Photobook (98p)</p>\r\n\r\n<p>- CD</p>\r\n\r\n<p>- Lyrics Paper</p>\r\n\r\n<p>-&nbsp;Sticker Set</p>\r\n\r\n<p>- Random Postcard (4ea)</p>\r\n\r\n<p>- Random Polaroid (2ea)</p>\r\n\r\n<p>-Random Double Sided Poster (1ea - folded)</p>\r\n', 'produk1621688014.jpg', 1),
(16, 9, 'TWICE - What is Love?', 390000, '<h1>TWICE - What is Love? (5th Mini Album)</h1>\r\n\r\n<p>Package</p>\r\n\r\n<p>-Cover</p>\r\n\r\n<p>- Photobook</p>\r\n\r\n<p>-&nbsp;CD-R</p>\r\n\r\n<p>- Photocard</p>\r\n\r\n<p>-&nbsp;Scratch Photocard</p>\r\n\r\n<p>-&nbsp;Lyrics Book</p>\r\n\r\n<p>- Clear Postcard</p>\r\n\r\n<p>- Sticker&nbsp;</p>\r\n', 'produk1621688447.jpg', 1),
(17, 9, 'TWICE - Yes or Yes', 390000, '<h1>TWICE - Yes or Yes (6th Mini Album)</h1>\r\n\r\n<p>package</p>\r\n\r\n<ul>\r\n	<li>Cover + CD-R&nbsp;+ Photobook + Photocard + Yes or Yes Card</li>\r\n	<li>Photocard Set<em>&nbsp;(*Pre-order only)</em></li>\r\n	<li>Poster<em>&nbsp;(*Pre-order only; included until supplies last; folded)</em></li>\r\n</ul>\r\n', 'produk1621688614.jpg', 1),
(18, 9, 'TWICE - Fancy You ', 390000, '<h1>TWICE - Fancy You (7th Mini Album)</h1>\r\n\r\n<p>package</p>\r\n\r\n<ul>\r\n	<li>Cover + Sleeve + Photobook + CD-R + Fancy Lenticular + Photocard + Fancy Sticker</li>\r\n	<li>Photocard Set&nbsp;<em>(*Pre-order only)</em></li>\r\n	<li>Poster&nbsp;<em>(*Pre-order only; included until supplies last; folded)</em></li>\r\n</ul>\r\n', 'produk1621688818.jpg', 1),
(19, 9, 'TWICE - Taste of Love', 470000, '<h1>[Pre-Order] TWICE - Taste of Love (10th Mini Album)</h1>\r\n\r\n<p><strong>You will receive a random version of this album [TASTE, FALLEN, IN LOVE].</strong></p>\r\n\r\n<p><strong>package</strong></p>\r\n\r\n<ul>\r\n	<li>Cover/Sleeve + Photobook (76p) + CD-R + Booklet (Lenticular + Tasting Card) + Coaster + Random Photocard (5ea)</li>\r\n	<li>Photocard Set, 10 cards in 1 set&nbsp;(*Pre-order only)</li>\r\n	<li>Poster&nbsp;(*Pre-order only, included until supplies last; folded)</li>\r\n</ul>\r\n', 'produk1621689016.jpg', 1),
(20, 10, 'IU - Lilac', 761000, '<h1>IU - Lilac (5th Album)</h1>\r\n\r\n<p><strong>package:</strong></p>\r\n\r\n<ul>\r\n	<li>Photobook (72p) +&nbsp;CD + Lyric Book (16p) + AR Photocard + Photocard + ID Photo Kit + Artwork Sticker</li>\r\n</ul>\r\n\r\n<p><strong>Pre-Order only:</strong></p>\r\n\r\n<ul>\r\n	<li>Poster -&nbsp;<em>(included until supplies last; folded)</em></li>\r\n</ul>\r\n', 'produk1621689347.jpg', 1),
(21, 10, 'IU- Love poem', 230000, '<p>IU 5th mini Album - Love poem CD + Poster</p>\r\n\r\n<p><strong>Package:</strong></p>\r\n\r\n<p>- Photobook(112p / 140 x 190 x 12mm)</p>\r\n\r\n<p>- CD</p>\r\n\r\n<p>- Photocard(Random 1 out of 2)</p>\r\n\r\n<p>- Bookmark(Random 1 out of 2)</p>\r\n\r\n<p>- Poster(1st Press Only)</p>\r\n', 'produk1621690586.jpg', 1),
(22, 4, 'Dont Mess Up My Tempo', 390000, '<p>EXO 5th Album - DON&#39;T MESS UP MY TEMPO (Random Ver) CD + Poster</p>\r\n\r\n<p><strong>Package:</strong></p>\r\n\r\n<p>- CD (1 Random Cover /Allegro Ver , Moderato Ver, Andante Ver)</p>\r\n\r\n<p>- Postcard (Random 1 Out of 8) 1st press only / Domestic version</p>\r\n\r\n<p>- Photocard (Random 1 Out of 8)</p>\r\n\r\n<p>-&nbsp;Poster(Random 1 Out of 3 / 1st Press Only)</p>\r\n', 'produk1621690879.jpg', 1),
(23, 4, 'EXO- XOXO', 230000, '<p>[Re-release] EXO 1st Album - XOXO (KISS VER) CD</p>\r\n\r\n<p><strong>Package(KISS VER)</strong></p>\r\n\r\n<p>-&nbsp;CD : Yearbook Package</p>\r\n\r\n<p>- Sticker</p>\r\n', 'produk1621691056.jpg', 1),
(24, 7, 'BTS – Skool Luv Affair', 225000, '<p><strong>Album Info:</strong><br />\r\nTanggal RIlis: 12 Februari 2014<br />\r\nNegara: Korea<br />\r\nLabel/Distributor: LOEN Entertainment<br />\r\nDetail: CD + Booklet + Photocard<br />\r\nPoster:&nbsp;<strong>Habis</strong></p>\r\n', 'produk1621837455.jpg', 1),
(25, 4, 'EXO K – Overdose', 215000, '<p><strong>Album Info</strong><br />\r\nTanggal Rilis: 21 April 2014<br />\r\nNegara: Korea<br />\r\nBonus: &ndash;</p>\r\n', 'produk1621837684.jpg', 1),
(26, 7, 'BTS – LOVE YOURSELF – Tear', 280000, '<p><strong>Album Info:</strong><br />\r\nTanggal Rilis: 18 Mei 2018<br />\r\nNegara: Korea<br />\r\nLabel/Distributor: LOEN Entertainment<br />\r\nDetail: CD + 104p Photobook + 20p Minibook + Random Photocard + Special Photocard + Standing Photo</p>\r\n', 'produk1621837887.jpg', 1),
(27, 7, 'BTS – Young Forever', 340000, '<h1>BTS &ndash; Young Forever (Night Version)</h1>\r\n\r\n<p><strong>Album Info:</strong><br />\r\nTanggal Rilis: 2 Mei 2016<br />\r\nNegara: Korea<br />\r\nLabel/Distributor: LOEN Entertainment<br />\r\nDetail: 2 CD + Photobook 112p + Random Photocard + Mini Photocard<br />\r\nPoster: Tidak ada*<br />\r\n*tidak ada poster di luar album yang digulung, poster yang terlipat di dalam album masih.</p>\r\n', 'produk1621838023.jpg', 1),
(28, 7, 'BTS – I Need U', 225000, '<h1>BTS &ndash; I Need U (Japanese Ver.) (Normal Edition)</h1>\r\n\r\n<p><strong>Album Info:</strong><br />\r\nTanggal Rilis: 8 Desember 2015<br />\r\nNegara: Jepang<br />\r\nLabel/Distributor: Universal Music<br />\r\nDetails: CD<br />\r\nPoster: &ndash;<br />\r\nBonus First Press Edition: Habis</p>\r\n\r\n<p>&nbsp;</p>\r\n', 'produk1621838146.jpg', 1),
(29, 8, 'Super Junior – Mamacita', 275000, '<h1>Super Junior &ndash; Mamacita (Type A)</h1>\r\n\r\n<p><strong>Album Info:</strong><br />\r\nTanggal Rilis: 1 September 2014<br />\r\nNegara: Korea<br />\r\nBonus: &ndash;</p>\r\n', 'produk1621838345.jpg', 1),
(30, 8, 'Super Junior D&E – DANGER', 250000, '<h1>Super Junior D&amp;E &ndash; DANGER</h1>\r\n\r\n<p><strong>Album Info</strong><br />\r\nTanggal Rilis: 15 April 2019<br />\r\nNegara: Korea<br />\r\nLabel/Distributor: SM Entertainment<br />\r\nDetail: COMING SOON<br />\r\nPoster: ADA*<br />\r\n*tanyakan ketersediaan untuk order setelah tanggal rilis</p>\r\n', 'produk1621838721.jpg', 1),
(31, 8, 'Super Junior – Opera', 370000, '<h1>Super Junior &ndash; Opera (CD+DVD)</h1>\r\n\r\n<p><strong>Album Info:</strong><br />\r\nTanggal Rilis: 9 Mei 2012<br />\r\nNegara: Jepang<br />\r\nLabel/Distributor: Avex Marketing<br />\r\nBonus: &ndash;</p>\r\n', 'produk1621838910.jpg', 1),
(32, 11, 'ASTRO – Venus', 495000, '<h1>ASTRO &ndash; Venus [Japan]</h1>\r\n\r\n<p><strong>Album Info</strong><br />\r\nTanggal Rilis: 3 April 2019<br />\r\nNegara: Jepang<br />\r\nLabel/Distributor: Universal Music Japan<br />\r\nPoster:&nbsp;<strong>Tidak Ada</strong></p>\r\n', 'produk1621839776.jpg', 1),
(33, 11, 'ASTRO – Autumn Story', 225000, '<h1>ASTRO &ndash; Autumn Story [3rd Mini Album]</h1>\r\n\r\n<p><strong>Album Info</strong><br />\r\nTanggal Rilis: 10 November 2016<br />\r\nNegara: Korea Selatan<br />\r\nDistributor: Interpark<br />\r\nDetail: &ndash;</p>\r\n', 'produk1621839913.jpg', 1),
(34, 8, 'Yesung – Pink Magic', 235000, '<h1>Yesung &ndash; Pink Magic [3rd Mini Album]</h1>\r\n\r\n<p><strong>Album Info</strong><br />\r\nTanggal Rilis: 18 Juni 2019<br />\r\nNegara: Korea<br />\r\nLabel/Distributor: SM Entertainment</p>\r\n', 'produk1621840101.jpg', 1),
(35, 8, 'Yesung – Story [Regular Edition]', 425000, '<h1>Yesung &ndash; Story [Regular Edition]</h1>\r\n\r\n<p><strong>Album Info</strong></p>\r\n\r\n<p>Tanggal Rilis: 20 Februari 2019<br />\r\nNegara: Jepang<br />\r\nDetail: CD<br />\r\nPoster: Tidak Ada<br />\r\nBonus: Random Photocard + Bookmark&nbsp;<strong>*First Press Only*</strong></p>\r\n', 'produk1621840211.jpg', 1),
(36, 8, 'Yesung – Story', 600000, '<h1>Yesung &ndash; Story [CD + DVD] [Limited Edition]</h1>\r\n\r\n<p><strong>Album Info</strong></p>\r\n\r\n<p>Tanggal Rilis: 20 Februari 2019<br />\r\nNegara: Jepang<br />\r\nDetail: CD + DVD + Random Photocard<br />\r\nPoster: Tidak Ada<br />\r\nBonus: Bookmark&nbsp;<strong>*First Press Only*</strong></p>\r\n', 'produk1621840445.jpg', 1),
(37, 10, 'IU – Palette', 255000, '<h1><strong>IU &ndash; Palette</strong></h1>\r\n\r\n<p><strong>Album Info:</strong><br />\r\nTanggal Rilis: 14 April 2017<br />\r\nNegara: Korea<br />\r\nLabel/Distributor: Loen Entertainment<br />\r\nDetails:</p>\r\n', 'produk1621840798.jpg', 1),
(38, 12, 'Stray Kids – I am WHO', 235000, '<h1>Stray Kids &ndash; I am WHO</h1>\r\n\r\n<p><strong>Album Info:</strong><br />\r\nTanggal Rilis: 6 Agustus 2018<br />\r\nNegara: Korea<br />\r\nLabel/Distributor: JYP Entertainment<br />\r\nDetails: CD + Photobook + QR Photocards + Lyric Poster</p>\r\n', 'produk1621841073.jpg', 1),
(39, 12, 'Stray Kids Mixtape', 235000, '<h1>Stray Kids Mixtape</h1>\r\n\r\n<p><strong>Album Info:</strong><br />\r\nTanggal Rilis: 08 Januari 2018<br />\r\nNegara: Korea<br />\r\nLabel/Distributor: JYP Entertainment<br />\r\nDetails: &ndash;</p>\r\n', 'produk1621842401.jpg', 1),
(40, 4, 'EXO – The War Kokobop', 265000, '<h1>EXO &ndash; The War Kokobop (Korean Ver.)</h1>\r\n\r\n<p><strong>Album Info:</strong><br />\r\nTanggal Rilis: 29 Juli 2017<br />\r\nNegara: Korea<br />\r\nLabel/Distributor: SM Entertainment<br />\r\nDetails: CD + 92p Photobooklet + Random Photocard<br />\r\nPoster:&nbsp;<strong>Habis</strong></p>\r\n\r\n<p>&nbsp;</p>\r\n', 'produk1621842660.jpg', 1),
(41, 13, '2PM – Hands Up', 225000, '<h1>2PM &ndash; Hands Up</h1>\r\n\r\n<p>Album Info</p>\r\n\r\n<p>Tanggal Rilis : 21 Juni 2011<br />\r\nNegara : Korea<br />\r\nLabel : JYP Entertainment<br />\r\nDetail : &ndash;</p>\r\n', 'produk1621843027.jpg', 1),
(42, 13, '2PM – Go Crazy', 290000, '<h1>2PM &ndash; Go Crazy</h1>\r\n\r\n<p><strong>Album Info</strong></p>\r\n\r\n<p>Tanggal Rilis : 15 September 2014<br />\r\nNegara : Korea<br />\r\nLabel : JYP Entertainment<br />\r\nDetail : &ndash;</p>\r\n', 'produk1621843122.jpg', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `category_id` (`category_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `category` (`category_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
